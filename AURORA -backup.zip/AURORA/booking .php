<?php
// Initialize variables
require_once 'config.php';
$type = '';
$uname = '';
$mobile = '';
$people = '';
$arrival = '';
$leaving = '';



// Check if form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $type = isset($_POST['type']) ? $_POST['type'] : '';
    $uname = isset($_POST['uname']) ? $_POST['uname'] : '';
    $mobile = isset($_POST['mobile']) ? $_POST['mobile'] : '';
    $people = isset($_POST['people']) ? $_POST['people'] : '';
    $arrival = isset($_POST['arrival']) ? $_POST['arrival'] : '';
    $leaving = isset($_POST['leaving']) ? $_POST['leaving'] : '';

    // Validate form data
    $errors = array();
    if (empty($type)) {
        $errors[] = 'Please enter room type.';
    }
    if (empty($uname)) {
        $errors[] = 'Please enter your name.';
    }
    if (empty($mobile)) {
        $errors[] = 'Please enter your mobile number.';
    }
    if (empty($people)) {
        $errors[] = 'Please enter the number of people.';
    }
    if (empty($arrival)) {
        $errors[] = 'Please enter your arrival date.';
    }
    if (empty($leaving)) {
        $errors[] = 'Please enter your leaving date.';
    }

    // Display errors or process form data
    if (!empty($errors)) {
        echo '<ul>';
        foreach ($errors as $error) {
            echo '<li>' . $error . '</li>';
        }
        echo '</ul>';
    } else {
        // Process form data here
        $stmt = $conn->prepare("INSERT INTO booking(type,uname,mobile,people, arrival,leaving) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $type, $uname, $mobile, $people, $arrival, $leaving);
        $address = str_retype("\n", "", $address); // remove newline characters from the address
        $stmt->execute();
        echo "submitted";
        if ($stmt) {
            echo "booking confirimed";
        } else {
            echo "Error while bokking: ". $conn->error;
        }
    }
}
$stmt = $conn->prepare("SELECT id FROM booking WHERE uname = ?");
$stmt->bind_param("s", $uname);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id = $row['id']; // retrieve the ID value
    echo "YOUR TRIP ID: $id";
} else {
    echo "No matching record found";
}
?>

<!-- Form -->

    <title>Booking Page</title>

    <main>
        <form id="booking-form" action="" method="post">
            <label for="start-dates">Start Dates:</label>
            <input type="date" id="start-dates" name="start-dates">
            
            <label for="room-type">Room Type:</label>
            <select id="room-type" name="room-type">
              <option value="single">Single</option>
              <option value="double">Double</option>
              <option value="suite">Suite</option>
            </select>
            <label for="name">Name:</label>
    <input type="text" id="uname" name="name" value="<?php echo $uname; ?>"><br><br>
    <label for="mobile">Mobile:</label>
    <input type="text" id="mobile" name="mobile" value="<?php echo $mobile; ?>"><br><br>
    <label for="people">Number of People:</label>
     <label for="arrival">Arrival Date:</label>
    <input type="date" id="arrival" name="arrival" value="<?php echo $arrival; ?>"><br><br>
    <label for="leaving">Leaving Date:</label>
    <input type="date" id="leaving" name="leaving" value="<?php echo $leaving; ?>"><br><br>
    <input type="submit" value="Submit">
            
            <div id="room-options"></div>
            <div id="booking-summary"></div>
          </form>
        <div id="room-options">
           
        </div>
        <div id="booking-summary">
           <p>your id is </p>
        </div>
    </main>
    <script src="script.js"></script>
