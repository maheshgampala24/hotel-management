<?php
require_once 'database.php';

// Availability API
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'availability') {
    $travelDates = $_POST['travelDates'];
    $roomType = $_POST['roomType'];
    $rooms = getAvailableRooms($travelDates, $roomType);
    echo json_encode($rooms);
    exit;
}

// Booking API
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'booking') {
    $roomId = $_POST['roomId'];
    $booking = createBooking($roomId);
    echo json_encode($booking);
    exit;
}

// Payment API
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'payment') {
    $paymentMethod = $_POST['paymentMethod'];
    $amount = $_POST['amount'];
    $payment = createPayment($paymentMethod, $amount);
    echo json_encode($payment);
    exit;
}

function createPayment($paymentMethod, $amount) {
    $userId = $_SESSION['user_id'];
    $paymentStatus = 'pending';
    $paymentDate = date('Y-m-d');
    $query = "INSERT INTO payments (user_id, payment_method, payment_status, amount, payment_date) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isssd", $userId, $paymentMethod, $paymentStatus, $amount, $paymentDate);
    $stmt->execute();
    $paymentId = $stmt->insert_id;
    $payment = array(
        'payment_method' => $paymentMethod,
        'amount' => $amount,
        'payment_status' => $paymentStatus,
        'payment_date' => $paymentDate
    );
    return $payment;
}

function getPaymentStatus($paymentId) {
    $query = "SELECT payment_status FROM payments WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $paymentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $paymentStatus = $result->fetch_assoc();
    return $paymentStatus['payment_status'];
}

function getAvailableRooms($travelDates, $roomType) {
    $db = connectToDatabase();
    $query = "SELECT * FROM rooms WHERE room_type = '$roomType' AND availability = 1";
    $result = mysqli_query($db, $query);
    $rooms = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $rooms[] = array(
            'id' => $row['id'],
            'roomType' => $row['room_type'],
            'rate' => $row['rate']
        );
    }
    return $rooms;
}

function createBooking($roomId) {
    $db = connectToDatabase();
    $query = "INSERT INTO bookings (room_id, travel_dates) VALUES ('$roomId', NOW())";
    mysqli_query($db, $query);
    $bookingId = mysqli_insert_id($db);
    $booking = array(
        'id' => $bookingId,
        'roomType' => getRoomType($roomId),
        'rate' => getRoomRate($roomId),
        'travelDates' => getTravelDates($bookingId )
    );
    return $booking;
}

function getRoomType($roomId) {
    $db = connectToDatabase();
    $query = "SELECT room_type FROM rooms WHERE id = '$roomId'";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['room_type'];
}

function getRoomRate($roomId) {
    $db = connectToDatabase();
    $query = "SELECT rate FROM rooms WHERE id = '$roomId'";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['rate'];
}

function getTravelDates($bookingId) {
    $db = connectToDatabase();
    $query = "SELECT travel_dates FROM bookings WHERE id = '$bookingId'";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['travel_dates'];
}

function connectToDatabase() {
    $db = mysqli_connect('localhost', 'username', 'password', 'database');
    if (!$db) {
        die('Could not connect to database');
    }
    return $db;
}