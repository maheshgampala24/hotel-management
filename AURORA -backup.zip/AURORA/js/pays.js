const form = document.getElementById('payment-form');
const paymentStatus = document.getElementById('payment-status');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const paymentMethod = document.getElementById('payment-method').value;
    const amount = document.getElementById('amount').value;
    fetch('/api/payment', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ paymentMethod, amount })
    })
    .then(response => response.json())
    .then(data => {
        const paymentStatusHTML = `
            <h2>Payment Status:</h2>
            <p>Payment Method: ${data.payment_method}</p>
            <p>Amount: ${data.amount}</p>
            <p>Payment Status: ${data.payment_status}</p>
        `;
        paymentStatus.innerHTML = paymentStatusHTML;
    })
    .catch(error => console.error(error));
});