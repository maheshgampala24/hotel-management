
form.addEventListener('submit', (e) => {
  e.preventDefault(); // Prevent default form submission
  // ...
});


    // Get the form and its elements
    const form = document.getElementById('booking-form');
    const travelDatesInput = document.getElementById('travel-dates');
    const roomTypeSelect = document.getElementById('room-type');
    const roomOptionsDiv = document.getElementById('room-options');
    const bookingSummaryDiv = document.getElementById('booking-summary');

    // Add event listener to the form submission
    form.addEventListener('submit', (e) => {
      e.preventDefault(); // Prevent default form submission

      // Get the selected travel dates and room type
      const travelDates = travelDatesInput.value;
      const roomType = roomTypeSelect.value;

      // Fetch room options from a fictional API (replace with your actual API)
      fetch(`https://example.com/api/room-options?travelDates=${travelDates}&roomType=${roomType}`)
        .then(response => response.json())
        .then((roomOptions) => {
          // Display room options
          roomOptionsDiv.innerHTML = '';
          roomOptions.forEach((option) => {
            const roomOptionHTML = `
              <div>
                <h2>${option.roomType}</h2>
                <p>Price: ${option.price}</p>
                <button data-room-id="${option.id}">Book Now</button>
              </div>
            `;
            roomOptionsDiv.innerHTML += roomOptionHTML;
          });

          // Add event listener to the "Book Now" buttons
          const bookNowButtons = roomOptionsDiv.querySelectorAll('button');
          bookNowButtons.forEach((button) => {
            button.addEventListener('click', (e) => {
              const roomId = e.target.dataset.roomId;
              // Fetch booking summary from a fictional API (replace with your actual API)
              fetch(`https://example.com/api/booking-summary?roomId=${roomId}&travelDates=${travelDates}`)
                .then(response => response.json())
                .then((bookingSummary) => {
                  // Display booking summary
                  bookingSummaryDiv.innerHTML = `
                    <h2>Booking Summary</h2>
                    <p>Room Type: ${bookingSummary.roomType}</p>
                    <p>Travel Dates: ${bookingSummary.travelDates}</p>
                    <p>Price: ${bookingSummary.price}</p>
                    <button>Confirm Booking</button>
                  `;
                });
            });
          });
        });
    });